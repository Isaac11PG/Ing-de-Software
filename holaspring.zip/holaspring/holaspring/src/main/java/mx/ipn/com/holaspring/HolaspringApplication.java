package mx.ipn.com.holaspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HolaspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(HolaspringApplication.class, args);
	}

}
